import React from 'react';
import { Globe } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#F7F7F7] border-t border-[#DDDDDD] mt-0 py-12 text-sm text-[#222222]">
      <div className="max-w-[1120px] mx-auto px-6">
        {/* Footer Link Columns */}
        <div className="grid grid-cols-3 gap-8 pb-10 border-b border-[#DDDDDD]">
          <div className="space-y-3">
            <h4 className="font-semibold text-[#222222]">Support</h4>
            <div className="space-y-2 text-[#717171]">
              <div><a href="#" className="hover:underline">Help Centre</a></div>
              <div><a href="#" className="hover:underline">AirCover</a></div>
              <div><a href="#" className="hover:underline">Anti-discrimination</a></div>
              <div><a href="#" className="hover:underline">Disability support</a></div>
              <div><a href="#" className="hover:underline">Cancellation options</a></div>
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="font-semibold text-[#222222]">Hosting</h4>
            <div className="space-y-2 text-[#717171]">
              <div><a href="#" className="hover:underline">Airbnb your home</a></div>
              <div><a href="#" className="hover:underline">AirCover for Hosts</a></div>
              <div><a href="#" className="hover:underline">Hosting resources</a></div>
              <div><a href="#" className="hover:underline">Community forum</a></div>
              <div><a href="#" className="hover:underline">Hosting responsibly</a></div>
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="font-semibold text-[#222222]">Airbnb</h4>
            <div className="space-y-2 text-[#717171]">
              <div><a href="#" className="hover:underline">Newsroom</a></div>
              <div><a href="#" className="hover:underline">New features</a></div>
              <div><a href="#" className="hover:underline">Careers</a></div>
              <div><a href="#" className="hover:underline">Investors</a></div>
              <div><a href="#" className="hover:underline">Airbnb.org emergency stays</a></div>
            </div>
          </div>
        </div>

        {/* Bottom copyright and legal */}
        <div className="pt-6 flex items-center justify-between text-xs text-[#717171]">
          <div className="flex items-center gap-2 flex-wrap">
            <span>© 2026 Airbnb, Inc.</span>
            <span>·</span>
            <a href="#" className="hover:underline">Privacy</a>
            <span>·</span>
            <a href="#" className="hover:underline">Terms</a>
            <span>·</span>
            <a href="#" className="hover:underline">Sitemap</a>
            <span>·</span>
            <a href="#" className="hover:underline">Company details</a>
          </div>

          <div className="flex items-center gap-6 font-semibold text-[#222222]">
            <div className="flex items-center gap-2 cursor-pointer hover:underline">
              <Globe className="w-4 h-4" />
              <span>English (IN)</span>
            </div>
            <div className="cursor-pointer hover:underline">
              <span>₹ INR</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};
