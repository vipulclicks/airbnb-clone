import React, { useState } from 'react';
import { Share, Heart } from 'lucide-react';

interface ListingHeaderProps {
  title: string;
  onToast: (msg: string) => void;
}

export const ListingHeader: React.FC<ListingHeaderProps> = ({ title, onToast }) => {
  const [isSaved, setIsSaved] = useState(false);

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
    }
    onToast("Link copied to clipboard!");
  };

  const handleSave = () => {
    setIsSaved(!isSaved);
    onToast(!isSaved ? "Saved to your wishlist!" : "Removed from wishlist");
  };

  return (
    <div className="pt-6 pb-4 flex flex-col md:flex-row md:items-end justify-between gap-4">
      <div>
        <h1 className="text-[26px] font-semibold text-[#222222] tracking-tight leading-tight">
          {title}
        </h1>
      </div>

      <div className="flex items-center gap-4 text-sm font-semibold text-[#222222]">
        <button
          onClick={handleShare}
          className="flex items-center gap-2 underline underline-offset-2 hover:bg-[#F7F7F7] px-2 py-1.5 rounded-md transition-colors"
        >
          <Share className="w-4 h-4" />
          <span>Share</span>
        </button>

        <button
          onClick={handleSave}
          className="flex items-center gap-2 underline underline-offset-2 hover:bg-[#F7F7F7] px-2 py-1.5 rounded-md transition-colors"
        >
          <Heart
            className={`w-4 h-4 transition-colors ${
              isSaved ? 'fill-[#FF385C] text-[#FF385C]' : 'text-[#222222]'
            }`}
          />
          <span>{isSaved ? 'Saved' : 'Save'}</span>
        </button>
      </div>
    </div>
  );
};
