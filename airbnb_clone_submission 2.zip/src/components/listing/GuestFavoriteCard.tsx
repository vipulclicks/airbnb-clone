import React from 'react';
import { LISTING_DATA } from '../../data/listing';

export const GuestFavoriteCard: React.FC = () => {
  return (
    <div className="border border-[#DDDDDD] rounded-2xl p-6 flex items-center justify-between my-6 bg-white shadow-sm">
      {/* Left: Laurel Wreath & Label */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1">
          {/* Left Laurel Branch */}
          <svg className="w-8 h-12 text-[#222222] fill-current" viewBox="0 0 32 48">
            <path d="M12 4C10 8 7 14 7 22c0 9 5 16 11 20-3-4-5-10-5-16 0-7 3-13 6-18-4-2-7-3-7-4z" />
          </svg>
          <div className="font-bold text-base text-[#222222] leading-tight">
            Guest<br />favourite
          </div>
          {/* Right Laurel Branch */}
          <svg className="w-8 h-12 text-[#222222] fill-current -scale-x-100" viewBox="0 0 32 48">
            <path d="M12 4C10 8 7 14 7 22c0 9 5 16 11 20-3-4-5-10-5-16 0-7 3-13 6-18-4-2-7-3-7-4z" />
          </svg>
        </div>
      </div>

      {/* Center: Reassurance Text */}
      <div className="text-center px-4 max-w-[280px]">
        <p className="text-sm font-semibold text-[#222222] leading-snug">
          One of the most loved homes on Airbnb, according to guests
        </p>
      </div>

      {/* Right: Rating & Review count */}
      <div className="flex items-center gap-6">
        <div className="text-center">
          <div className="text-lg font-bold text-[#222222]">
            {LISTING_DATA.overallRating}
          </div>
          <div className="flex text-xs text-[#222222]">
            ★★★★★
          </div>
        </div>

        <div className="h-10 w-px bg-[#DDDDDD]"></div>

        <div className="text-center">
          <div className="text-lg font-bold text-[#222222]">
            {LISTING_DATA.totalReviews}
          </div>
          <div className="text-xs font-semibold text-[#222222] underline">
            Reviews
          </div>
        </div>
      </div>
    </div>
  );
};
