import React, { useState } from 'react';
import confetti from 'canvas-confetti';

interface PromoBannerProps {
  onToast: (msg: string) => void;
}

export const PromoBanner: React.FC<PromoBannerProps> = ({ onToast }) => {
  const [claimed, setClaimed] = useState(false);

  const handleClaim = () => {
    if (!claimed) {
      setClaimed(true);
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 }
      });
      onToast("🎉 10% off coupon claimed for your booking!");
    } else {
      onToast("Coupon already applied to your booking!");
    }
  };

  return (
    <div className="border border-[#DDDDDD] rounded-xl p-4 flex items-center justify-between shadow-[0_1px_4px_rgba(0,0,0,0.04)] bg-white mb-6">
      <div className="flex items-center gap-3.5">
        <div className="w-8 h-8 rounded-lg flex items-center justify-center text-emerald-600">
          {/* Green Tag Icon */}
          <svg className="w-6 h-6 fill-[#22C55E]" viewBox="0 0 24 24">
            <path d="M21.41 11.58l-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58.55 0 1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41 0-.55-.23-1.06-.59-1.42zM5.5 7C4.67 7 4 6.33 4 5.5S4.67 4 5.5 4 7 4.67 7 5.5 6.33 7 5.5 7z" />
          </svg>
        </div>
        <div>
          <div className="text-sm font-semibold text-[#222222]">
            Get 10% off your next stay.
          </div>
          <button
            onClick={() => onToast("Discount automatically applied at checkout")}
            className="text-xs text-[#222222] font-semibold underline hover:text-black cursor-pointer"
          >
            Terms apply
          </button>
        </div>
      </div>

      <button
        onClick={handleClaim}
        className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all border ${
          claimed
            ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
            : 'bg-[#F7F7F7] hover:bg-[#EBEBEB] text-[#222222] border-[#DDDDDD] active:scale-95'
        }`}
      >
        {claimed ? 'Claimed' : 'Claim'}
      </button>
    </div>
  );
};
