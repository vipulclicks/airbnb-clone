import { useState, useEffect } from 'react';
import { Navbar } from './components/header/Navbar';
import { StickyNavHeader } from './components/header/StickyNavHeader';
import { ListingHeader } from './components/listing/ListingHeader';
import { HeroPhotoGrid } from './components/listing/HeroPhotoGrid';
import { PromoBanner } from './components/listing/PromoBanner';
import { GuestFavoriteCard } from './components/listing/GuestFavoriteCard';
import { HostOverview } from './components/listing/HostOverview';
import { Description } from './components/listing/Description';
import { WhereYouSleep } from './components/listing/WhereYouSleep';
import { AmenitiesSection } from './components/listing/AmenitiesSection';
import { CalendarSection } from './components/listing/CalendarSection';
import { ReviewsSection } from './components/listing/ReviewsSection';
import { LocationSection } from './components/listing/LocationSection';
import { HostSection } from './components/listing/HostSection';
import { ThingsToKnow } from './components/listing/ThingsToKnow';
import { MoreStaysNearby } from './components/listing/MoreStaysNearby';
import { ReservationCard } from './components/reservation/ReservationCard';
import { Footer } from './components/listing/Footer';
import { PhotoTourModal } from './components/modals/PhotoTourModal';
import { LightboxModal } from './components/modals/LightboxModal';
import { Toast } from './components/ui/Toast';
import { LISTING_DATA } from './data/listing';

export default function App() {
  const [modalState, setModalState] = useState<{
    type: 'NONE' | 'PHOTO_TOUR' | 'LIGHTBOX';
    photoId?: string;
  }>({ type: 'NONE' });

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isStickyNavVisible, setIsStickyNavVisible] = useState(false);
  const [activeSection, setActiveSection] = useState('photos');

  // Sync state with URL params on load & popstate
  const syncWithUrl = () => {
    const params = new URLSearchParams(window.location.search);
    const modalParam = params.get('modal');
    const modalItemParam = params.get('modalItem');

    if (modalParam === 'PHOTO_TOUR_SCROLLABLE' && modalItemParam) {
      setModalState({ type: 'LIGHTBOX', photoId: modalItemParam });
    } else if (modalParam === 'PHOTO_TOUR_SCROLLABLE') {
      setModalState({ type: 'PHOTO_TOUR' });
    } else {
      setModalState({ type: 'NONE' });
    }
  };

  useEffect(() => {
    syncWithUrl();
    window.addEventListener('popstate', syncWithUrl);
    return () => window.removeEventListener('popstate', syncWithUrl);
  }, []);

  // Update URL helper
  const updateUrl = (modal?: string, modalItem?: string) => {
    const url = new URL(window.location.href);
    if (modal) {
      url.searchParams.set('modal', modal);
    } else {
      url.searchParams.delete('modal');
    }
    if (modalItem) {
      url.searchParams.set('modalItem', modalItem);
    } else {
      url.searchParams.delete('modalItem');
    }
    window.history.pushState({}, '', url.toString());
    syncWithUrl();
  };

  // Scroll detection for sticky header and active section
  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY;
      setIsStickyNavVisible(scrollY > 520);

      // Section tracking
      const sections = ['location', 'reviews', 'amenities', 'photos'];
      for (const sectionId of sections) {
        const el = document.getElementById(sectionId);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= 160) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleOpenPhotoTour = () => {
    updateUrl('PHOTO_TOUR_SCROLLABLE');
  };

  const handleOpenPhoto = (photoId: string) => {
    updateUrl('PHOTO_TOUR_SCROLLABLE', photoId);
  };

  const handleCloseModal = () => {
    updateUrl(undefined, undefined);
  };

  const handleBackToGrid = () => {
    updateUrl('PHOTO_TOUR_SCROLLABLE', undefined);
  };

  const handleNavigatePhoto = (photoId: string) => {
    updateUrl('PHOTO_TOUR_SCROLLABLE', photoId);
  };

  const handleReserveClick = () => {
    setToastMessage("You won't be charged yet");
  };

  const handleScrollToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      const yOffset = -80;
      const y = el.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-white font-sans">
      {/* Top Main Navbar */}
      <Navbar onSearchClick={() => setToastMessage("Search functionality")} />

      {/* Sticky Secondary Navigation Header */}
      <StickyNavHeader
        visible={isStickyNavVisible}
        activeSection={activeSection}
        onNavigate={handleScrollToSection}
        onReserveClick={handleReserveClick}
      />

      {/* Main Listing Content Container (max-width: 1120px desktop standard) */}
      <main className="max-w-[1120px] mx-auto px-6">
        {/* Listing Title & Actions */}
        <ListingHeader
          title={LISTING_DATA.title}
          onToast={(msg) => setToastMessage(msg)}
        />

        {/* 5-Photo Hero Grid */}
        <HeroPhotoGrid
          onOpenPhotoTour={handleOpenPhotoTour}
          onOpenPhoto={handleOpenPhoto}
        />

        {/* Two-Column Desktop Layout */}
        <div className="grid grid-cols-12 gap-16 relative">
          {/* Left Column (Primary Details) */}
          <div className="col-span-7">
            {/* Property Type & Specs */}
            <div className="pb-6 border-b border-[#EBEBEB]">
              <h2 className="text-[22px] font-semibold text-[#222222]">
                {LISTING_DATA.propertyType}
              </h2>
              <div className="text-base text-[#222222] mt-1 font-normal">
                {LISTING_DATA.specs}
              </div>
            </div>

            {/* Guest Favourite Laurel Badge */}
            <GuestFavoriteCard />

            {/* Host Overview & Feature Highlights */}
            <HostOverview />

            {/* Space Description */}
            <Description />

            {/* Where You'll Sleep */}
            <WhereYouSleep onPhotoClick={handleOpenPhotoTour} />

            {/* Amenities Section */}
            <AmenitiesSection />

            {/* Calendar Section */}
            <CalendarSection onToast={(msg) => setToastMessage(msg)} />
          </div>

          {/* Right Column (Sticky Reservation Sidebar) */}
          <div className="col-span-5">
            {/* Promo Discount Banner */}
            <PromoBanner onToast={(msg) => setToastMessage(msg)} />

            {/* Reservation Card Widget */}
            <ReservationCard
              onReserveClick={handleReserveClick}
              onToast={(msg) => setToastMessage(msg)}
            />
          </div>
        </div>

        {/* Full-Width Lower Sections */}
        {/* Reviews Breakdown & Cards */}
        <ReviewsSection onToast={(msg) => setToastMessage(msg)} />

        {/* Location & Map */}
        <LocationSection onToast={(msg) => setToastMessage(msg)} />

        {/* Detailed Host Section */}
        <HostSection onToast={(msg) => setToastMessage(msg)} />

        {/* Things to Know */}
        <ThingsToKnow onToast={(msg) => setToastMessage(msg)} />

        {/* More Stays Nearby */}
        <MoreStaysNearby onToast={(msg) => setToastMessage(msg)} />
      </main>

      {/* Desktop Footer */}
      <Footer />

      {/* Screen 2: Photo Tour Modal */}
      {modalState.type === 'PHOTO_TOUR' && (
        <PhotoTourModal
          onClose={handleCloseModal}
          onPhotoClick={handleOpenPhoto}
          onToast={(msg) => setToastMessage(msg)}
        />
      )}

      {/* Screen 3: Lightbox Modal */}
      {modalState.type === 'LIGHTBOX' && modalState.photoId && (
        <LightboxModal
          currentPhotoId={modalState.photoId}
          onBackToGrid={handleBackToGrid}
          onClose={handleCloseModal}
          onNavigatePhoto={handleNavigatePhoto}
        />
      )}

      {/* Interactive Toast Notification */}
      <Toast
        message={toastMessage}
        onClose={() => setToastMessage(null)}
      />
    </div>
  );
}
